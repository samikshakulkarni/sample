﻿using System.Collections.Generic;
using System.Linq;
using Biz.Interfaces;
using Core.Domains;
using Data;

namespace Biz.Services
{
    public class UserService : IUserService
    {
        #region Properties
        private readonly IRepository<User> _userRepo;

        #endregion

        #region Constructor

        public UserService()
        {
            _userRepo = new Repository<User>();
        }

        public UserService(IRepository<User> userRepo)
        {
            _userRepo = userRepo;
        }
        #endregion

        #region Methods
        public IQueryable<User> GetAll()
        {
            return _userRepo.Table;
        }

        public void Delete(User user)
        {
            _userRepo.Delete(user);
        }
        public User GetById(int id)
        {
            return _userRepo.GetById(id);
        }

        public IEnumerable<User> GetAllDataTable(string sortOrder, string search, bool? activeFilter = null)
        {
            var queryTable = _userRepo.Table;


            if (!string.IsNullOrWhiteSpace(search))
            {
                var searchValue = search.ToLower();

                queryTable = queryTable.Where(x => x.Name.ToLower().Contains(searchValue) || x.Address.ToLower().Contains(searchValue)||
                                                   
                                                   x.emailId.ToString().ToLower().Contains(searchValue));
            }
            switch (sortOrder)
            {
                case "Name":
                    return queryTable.OrderBy(x => x.Name);
                case "Name DESC":
                    return queryTable.OrderByDescending(x => x.Name);
               
            }
            return queryTable;


        }

        public void InsertOrUpdate(User user)
        {
            if (user.Id == 0)
            {
                _userRepo.Insert(user);
            }
            else
            {
                _userRepo.Update(user);
            }
        }
        #endregion
        
    }
}
