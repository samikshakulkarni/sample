﻿using System.Collections.Generic;
using System.Linq;
using Core.Domains;

namespace Biz.Interfaces
{
    public interface IUserService
    {

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        IQueryable<User> GetAll();
        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        User GetById(int id);

        /// <summary>
        /// Inserts or updates the model.
        /// </summary>
      
        void InsertOrUpdate(User user);

        /// <summary>
        /// Return Datatable for 
        /// </summary>
        /// <param name="sortOrder"></param>
        /// <param name="search"></param>
        /// <param name="activeFilter"></param>
        /// <returns></returns>
        IEnumerable<User> GetAllDataTable(string sortOrder, string search, bool? activeFilter = null);

        /// <summary>
        /// Delete Facility
        /// </summary>
     
        void Delete(User user);



    }
}