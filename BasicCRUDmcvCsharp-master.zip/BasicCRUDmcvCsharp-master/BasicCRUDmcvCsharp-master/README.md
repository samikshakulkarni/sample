# BasicCRUDmcvCsharp
Basic Add Edit Delete and Read functionality implemented using MVC
