﻿using Core.Domains;
using System.ComponentModel.DataAnnotations;

namespace Web.ViewModels
{
    public class UserViewModel
    {
        [Required]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [MaxLength(50)]
        [Display(Name = "Address")]
        public string Address { get; set; }

        [Required]
        [MaxLength(50)]
        [Display(Name = "Emailid")]
        public string emailid { get; set; }


        public UserViewModel(User user)
        {

            Id = user.Id;
            Name = user.Name;           
            Address = user.Address;
            emailid = user.emailId;
        }


        public UserViewModel()
        {

        }
    }
}

