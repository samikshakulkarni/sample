﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Core.Domains;

namespace Web.ViewModels
{
    public class UserIndexViewModel
    {
        public IEnumerable<UserViewModel> Users { get; set; }


        public UserIndexViewModel(IEnumerable<User> user)
        {
            Users = user.Select(x => new UserViewModel(x));
        }
    }


}