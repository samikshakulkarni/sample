﻿using System.Data.Entity.Infrastructure;
using System.Net;
using System.Web.Mvc;
using Biz.Interfaces;
using Core.Domains;
using Web.ViewModels;

namespace Web.Controllers
{
    public class UserController : Controller
    {

        #region Properties

        private readonly IUserService _userService;

        #endregion

        #region Constructor

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        #endregion

        // GET: Student
        public ViewResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            var users = _userService.GetAll();
            var model = new UserIndexViewModel(users);
            return View("Index",model);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UserViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = new User()
                    {
                        Id = model.Id,
                        Name = model.Name,                       
                        Address = model.Address,
                        emailId = model.emailid
                    };

                    _userService.InsertOrUpdate(user);
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException /* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View();
        }


        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var user = _userService.GetById(id ?? 0);

            if (user == null)
            {
                return HttpNotFound();
            }

            var model = new UserViewModel(user);
            return View("Edit", model);
        }

        [HttpPost, ActionName("Edit")]
        [ValidateAntiForgeryToken]
        public ActionResult EditPost(UserViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = new User()
                    {
                        Id = model.Id,
                        Name = model.Name,                       
                        Address = model.Address,                      
                        emailId = model.emailid
                    };

                    _userService.InsertOrUpdate(user);
                    return RedirectToAction("Index");
                }
            }
            catch (RetryLimitExceededException /* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return RedirectToAction("Edit", model);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var user = _userService.GetById(id ?? 0);

            if (user == null)
            {
                return HttpNotFound();
            }

            var model = new UserViewModel(user);
            return View("Details", model);
        }

        public ActionResult Delete(int? id, bool? saveChangesError = false)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (saveChangesError.GetValueOrDefault())
            {
                ViewBag.ErrorMessage = "Delete failed. Try again, and if the problem persists see your system administrator.";
            }

            var user = _userService.GetById(id ?? 0);
            var model = new UserViewModel(user);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View("Delete", model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id)
        {
            try
            {
                var user = _userService.GetById(id);
                _userService.Delete(user);
            }
            catch (RetryLimitExceededException/* dex */)
            {
                //Log the error (uncomment dex variable name and add a line here to write a log.
                return RedirectToAction("Delete", new { id = id, saveChangesError = true });
            }
            return RedirectToAction("Index");
        }


    }
}
